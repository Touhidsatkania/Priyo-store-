PRIYO STORE V99 — LOGIN UI + DASHBOARD BUILD FIX

This package is the next working candidate after V98.

Required flow:
1. App opens on PRIYO STORE Login Board.
2. Email/Mobile login tabs are available.
3. Login uses identifier + password; no OTP or verification-code screen.
4. Create Account opens as a separate Create Account Board.
5. Create Account fields: Full Name, Email address, Mobile Number, Password, Confirm Password.
6. Account creation directly creates the account and receives a login session; no verification-code gate.
7. Successful login goes directly to the PRIYO STORE Main Dashboard with the existing banner/live/feature structure.
8. Remember Me/session restore and Logout remain enabled.
9. Admin recognition: the app recognizes Touhidsatkania1@gmail.com as Admin in addition to the backend is_app_admin check. Privileged backend actions must still be authorized server-side.
10. Build workflow explicitly builds this repository source; it does not extract or select an older V91/V96/V98 ZIP.

Version:
- versionName: 1.0.99
- versionCode: 99 locally; GitHub release build uses a unique run-based versionCode override.

Important:
- V91/V96/V97 backups are not replaced by this package.
- This is not final success until the resulting APK is installed and the Login -> Create Account -> Login -> Dashboard flow is tested on the phone.
