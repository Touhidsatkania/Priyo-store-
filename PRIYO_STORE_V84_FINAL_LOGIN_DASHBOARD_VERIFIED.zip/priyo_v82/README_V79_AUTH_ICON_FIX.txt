PRIYO STORE V79 — AUTH + ICON FIX

1. CREATE ACCOUNT uses Supabase email OTP (/auth/v1/otp with create_user=true).
2. Verification uses /auth/v1/verify with type=email (the correct email OTP verification flow).
3. After successful verification, the returned access token is required and the user's password/name are set through /auth/v1/user.
4. Account is stored locally only after the Supabase password update succeeds.
5. Admin is detected by the configured admin email; login does NOT automatically open Admin Control Center.
6. Removed the old admin explanatory note from the login UI.
7. Launcher foreground and legacy icons were rebuilt with transparent/no-white outer edges.
8. Version: 1.0.79 (versionCode 79).

IMPORTANT: Gmail delivery still depends on Supabase Auth email/SMTP configuration. The app-side OTP flow is corrected, but no client code can force an email provider to deliver mail if the Supabase project email service is not configured/allowed.
