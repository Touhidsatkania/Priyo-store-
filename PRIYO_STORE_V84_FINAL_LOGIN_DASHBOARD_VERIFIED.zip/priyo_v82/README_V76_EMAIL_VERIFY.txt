PRIYO STORE V77 AUTH FIX

Changes:
- Removed automatic opening of Admin Control Center after Admin login.
- Admin role is detected automatically, and only the Admin account sees the Admin Control Center entry.
- Default Admin email is set to the Admin email used in the current PRIYO STORE login flow.
- Create Account keeps the email OTP verification flow: send 6-digit code, enter code, verify, then complete account creation.
- Email/password login uses Supabase Auth.
- The Admin explanatory note is not present in the login UI.
- Mobile login remains supported for existing local mobile accounts.

Important: actual email delivery depends on the Supabase Auth email/SMTP configuration. The app cannot send an email by itself.
