PRIYO STORE V84 — FINAL AUTHENTICATION / ADMIN / BANNER UPDATE

1. One common login screen for everyone.
2. No separate Admin Login screen.
3. Admin identity is detected after successful email login by the configured Admin Email.
4. Admin Control Center is hidden from non-admin users.
5. Admin login does not automatically open the Control Center.
6. Admin can manage Home banners and change banner image URL/asset, text, order and enabled state.
7. First login on a device: after successful password login, an email verification code is sent and must be verified.
8. After successful verification, that account + device is marked trusted locally; future logins on that same app/device do not require another OTP.
9. A new device has no trusted-device marker, so its first login requires email verification.
10. Create Account email verification remains enabled.
11. The old Admin explanatory note is removed from the source.
12. Version: 1.0.83 / versionCode 83.

Important:
- Trusted-device state is stored locally on the device. Clearing app data, uninstalling the app, or using a different device will require verification again.
- Supabase email delivery still depends on the project's Auth/SMTP/email configuration.
- GitHub Actions must complete successfully before installing the generated APK.
