PRIYO STORE V78 — AUTH + ICON FIX

1. Create Account uses Supabase email OTP flow.
2. Verification endpoint uses type=signup after the OTP is sent.
3. Admin email is detected internally; the login screen does not show an Admin note and login does not automatically open Admin Control Center.
4. Android adaptive launcher icon added for API 26+, with transparent/clean foreground to remove the white square around the icon.
5. versionCode=78, versionName=1.0.78.

IMPORTANT: Email delivery still depends on Supabase Auth email configuration. The app code cannot force Gmail delivery if the Supabase project's email provider/rate limits are not configured.
