PRIYO STORE V80

Fix focus: Android startup/WebView loading stability and launcher icon white-border removal.
OTP/auth changes are intentionally not the focus of this version.
