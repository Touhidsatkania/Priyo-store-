PRIYO STORE V81 — VERIFIED STARTUP + ICON FIX

Source checked:
- PRIYO_STORE_V81_VERIFIED_STARTUP_ICON_FIX.zip
- User-supplied screen recording 29801.mp4

What the recording confirms:
- The app DOES launch into the PRIYO STORE login screen.
- The old Admin email / Admin Control Center note is still visible in the installed build shown in the recording.

What V81 changes:
1. Removes that obsolete Admin note from the login UI.
2. Uses a cleaned adaptive launcher icon with a transparent outer area and dark adaptive background, avoiding the baked-in white rim.
3. Points both application icon and roundIcon to the same adaptive icon resource.
4. Adds one automatic WebView startup retry if the first local asset load fails.
5. Version: versionCode 81 / versionName 1.0.81.
6. OTP/Supabase authentication logic is intentionally left unchanged in this startup/icon-focused version.

Pre-package verification:
- MainActivity.java inspected and startup retry inserted.
- AndroidManifest.xml inspected; launcher and roundIcon both use adaptive icon.
- app/build.gradle verified at version 81.
- index.html JavaScript blocks all pass node --check.
- Launcher resources for mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi are present.
- V81 ZIP was rebuilt after all changes.
