PRIYO STORE V91 FINAL — VERIFICATION OFF

Purpose:
- Create Email or Mobile account without email verification/OTP.
- Login with the locally stored account without verification.
- Open the Dashboard immediately after successful local account creation/login.
- VersionCode 91 / VersionName 1.0.91.
- Kotlin dependency alignment is included to avoid the duplicate kotlin-stdlib 1.8.22 vs jdk7/jdk8 1.6.21 build failure.

Important:
This verification-free auth mode is local to the installed app/device. It does not use the Supabase email OTP flow.
