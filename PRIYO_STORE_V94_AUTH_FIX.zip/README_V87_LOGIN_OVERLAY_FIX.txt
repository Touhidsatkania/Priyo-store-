PRIYO STORE V88

Rechecked V86 and found a CSS precedence bug: .login-overlay was later forcing display:flex even after showDashboard() removed the show class. V88 changes the base login overlay to display:none; .login-overlay.show remains display:flex. This makes Login -> Dashboard navigation visually effective.
