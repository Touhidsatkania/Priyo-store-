PRIYO STORE V92

- Login/Create UI updated to the supplied reference layout.
- Create Account opens as the second screen; no OTP/verification step is presented.
- New local passwords are stored as PBKDF2-SHA256 hashes; legacy plaintext local accounts are upgraded after a successful login.
- Existing admin recognition is preserved without a separate admin login board.
- Android version bumped to 1.0.92 / versionCode 92.
- CI checks the version and new login markers before building debug and unsigned release APKs.
