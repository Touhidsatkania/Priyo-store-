PRIYO STORE V85 — FINAL VERIFICATION NOTES

Core fixes in this build:
- Successful email/password login explicitly closes login overlay and opens Home Dashboard.
- Existing authenticated session also opens Home Dashboard.
- Legacy auth-key mismatch (v55 vs v84) fixed so role/profile/admin checks use the current auth key.
- Old separate Admin Login/note is not present in the login UI.
- Separate Admin Control Center drawer entry is removed from normal user navigation; admin-only quick edit control is shown only for a recognized admin.
- Trusted-device verification remains one-time per device/account, with OTP required on a new device.
- Launcher adaptive icon foreground was rebuilt to avoid nesting a rounded-square icon inside another launcher mask, which caused the white frame seen on the device.
- Android versionCode 85 / versionName 1.0.85.

Validation performed before packaging:
- HTML duplicate IDs: none
- Embedded JavaScript blocks: 3; Node --check: PASS on all 3
- Required Android project files: present
- Workflow checks index.html and MainActivity.java
- ZIP integrity: verified after packaging

Important: real Gmail/Supabase authentication and Android launcher rendering still require the GitHub Actions APK build and installation on the device for final device-level verification.
