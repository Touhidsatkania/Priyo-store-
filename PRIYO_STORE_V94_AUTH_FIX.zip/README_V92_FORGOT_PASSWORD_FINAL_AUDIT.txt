PRIYO STORE V92 — FORGOT PASSWORD + FINAL AUDIT FIX

Changes verified in this package:
1. Forgot Password is now functional in the current local-account model.
   - Opens a dedicated recovery dialog.
   - Matches registered Email/Mobile and Full Name.
   - Allows a new password and confirmation.
   - New password is stored using the existing PBKDF2-SHA256 hashing flow.
   - No OTP/verification step is added to normal login or account creation.
   - The recovery dialog clearly notes that production-grade backend recovery should later use a verified recovery channel.

2. Fixed Admin recognition regression found in V92.
   - V92 auth storage key is now used consistently.
   - Legacy V84 auth is migrated once into V92 storage.
   - Admin identifier is configurable and defaults to the approved admin email.
   - Admin controls are exposed from the dashboard for recognized admin accounts; no separate admin login board is introduced.
   - Restored the missing Admin Control Center overlay required by the existing admin JavaScript.

3. Fixed supporting navigation/reference errors.
   - Live/Feed buttons no longer point to missing elements/functions.
   - window.doAction is exposed for the profile drawer's Store/Gallery actions.
   - Old V49 settings reference removed from the profile drawer path.
   - Live Moderator lookup now uses V92 local users.

4. Build/source audit.
   - versionCode 92 / versionName 1.0.92 preserved.
   - applicationId com.priyostore.app preserved.
   - approved PRIYO STORE icon preserved.
   - 4 default live cards verified.
   - 8 default feature tiles verified.
   - 3 embedded JavaScript blocks pass Node syntax checking.
   - Android manifest XML parses successfully.
   - Build workflow checks version 92 and builds debug + release outputs.
   - Stale V91 fallback reference removed from the workflow.

Important limitation:
The Android SDK/Gradle executable is not installed in this runtime, so a local APK compilation was not possible here. The source/workflow were statically validated, but this package should still be compiled by GitHub Actions before calling the APK build 100% verified.
