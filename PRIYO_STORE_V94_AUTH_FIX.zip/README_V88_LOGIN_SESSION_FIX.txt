PRIYO STORE V88 — LOGIN SESSION FIX

V88 requires a real Supabase access token before opening the Dashboard. Login/verification stores the session, and startup validates the token against /auth/v1/user. Stale local auth data alone can no longer bypass Login. Trusted-device login still requires a valid token. Logout clears both auth and session data.
