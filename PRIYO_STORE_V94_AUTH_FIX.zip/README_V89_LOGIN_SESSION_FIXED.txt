PRIYO STORE V89 — LOGIN SESSION FIXED

Root cause fixed:
- Trusted-device email login successfully authenticated with Supabase but did not pass the newly issued access/refresh token into enter(), so the Dashboard opened while no session was saved.
- After closing/reopening the app, startup correctly found no valid session and returned to Login, which made Login appear broken.

Fix:
- Trusted-device email login now calls enter(..., true, v), saving the real Supabase session before opening the Dashboard.
- Existing V88 startup token validation remains enabled.
- Registration verification and first-device OTP login continue to pass their real Supabase session into enter().

Validation:
- All 3 embedded JavaScript blocks pass Node --check.
- Android project structure retained.
- Original V88 behavior outside this targeted Login/session fix is preserved.
