# PRIYO STORE

- Version: 1.0.90 (versionCode 90)
- Application ID: com.priyostore.app
- Android target/compile SDK: 35

This build contains the V90 Login Session fix: first-device email OTP verification now persists the real Supabase access token, trusted-device login persists the token, and startup validates the stored token before opening the Dashboard.
