PRIYO STORE V86 — LOGIN → DASHBOARD NAVIGATION FIX

Problem addressed:
- Login could complete authentication but a later profile/dashboard/admin helper exception could prevent showDashboard() from running, leaving the Login overlay visible.
- Existing-session boot had the same ordering risk.

Fix:
- Dashboard navigation now happens immediately after the authenticated session is stored.
- Profile initialization, dashboard rendering, and admin-visibility refresh are isolated with try/catch so a non-critical UI helper cannot block Login → Dashboard navigation.
- Existing authenticated sessions use the same safe startup order.
- V85 UI, assets, authentication flow, trusted-device OTP flow, and launcher icon are preserved.

Version:
- Android versionCode 86
- Android versionName 1.0.86

This is a source-level fix. A GitHub Actions APK build and real-device login test are still required to confirm the behavior with the actual Supabase account.
