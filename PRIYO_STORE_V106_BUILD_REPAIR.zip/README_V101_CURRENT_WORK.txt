PRIYO STORE V101 — LOGIN → DASHBOARD WORKING CANDIDATE

Purpose:
This package is specifically for the current milestone:
PRIYO STORE Login -> Create Account/Login -> Main Dashboard.

AUTH RULES:
- No OTP.
- No "SEND VERIFICATION CODE" screen/button.
- No verification-code gate during normal account creation or login.
- Create Account directly creates the account and returns a login session.
- Successful login goes directly to the Main Dashboard.
- Email and Mobile login tabs are supported.
- Remember Me/session restore and Logout remain enabled.
- Admin is recognized automatically for touhidsatkania1@gmail.com; no admin marker is shown on the normal login UI.
- Backend admin authorization remains server-side through is_app_admin.

DASHBOARD:
- Uses the supplied PRIYO STORE Dashboard structure.
- Includes the banner assets home_ad1.png, home_ad2.png and home_welcome.png.
- Includes four live-card assets.
- Login overlay is hidden after successful session entry and Dashboard is shown.

BUILD:
- versionName: 1.0.101
- local versionCode: 101
- GitHub Actions uses a unique run-based versionCode override so every build is updateable.
- Release signing still requires the repository's existing PRIYO_STORE_KEYSTORE_* secrets.
- This package must be uploaded as project files to the repository root, not merely uploaded as a ZIP file.

TEST REQUIRED:
1. Install/update APK.
2. Confirm Login Board appears first.
3. Confirm there is no SEND VERIFICATION CODE/OTP UI.
4. Create Account.
5. Confirm direct session/login.
6. Confirm direct Dashboard with banners.
7. Close/reopen and test Remember Me/session.
8. Logout and confirm Login Board returns.
9. Test admin email recognition.
10. Only after these pass call it final success.
