PRIYO STORE V98 — LOGIN → DASHBOARD FIX

Scope of this version:
1. Login overlay no longer flashes as permanently visible before auth boot.
2. Supabase requests now have a 15-second timeout and a clearer network error.
3. Successful login now verifies the returned access token against /auth/v1/user before opening Dashboard.
4. Invalid/stale sessions are cleared instead of allowing a false Dashboard state.
5. Session refresh is revalidated before Dashboard entry.
6. Dashboard navigation is kept as the only post-login target in this work batch.
7. JavaScript syntax was checked with Node.js --check.

Build note:
The local environment does not contain Gradle, so a release APK could not be compiled here. The GitHub Actions workflow was updated to V98 and remains configured for the existing signing secrets.

Security note:
The private signing-key backup is intentionally not included in this V98 source ZIP. Keep the existing private signing backup offline/private.
