import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' }
  });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return response({ error: 'Method not allowed' }, 405);

  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
  const suppliedKey = req.headers.get('apikey') || '';
  if (!anonKey || suppliedKey !== anonKey) return response({ error: 'Unauthorized' }, 401);

  let body: any;
  try { body = await req.json(); } catch { return response({ error: 'Invalid JSON' }, 400); }

  const email = String(body?.email || '').trim().toLowerCase();
  const phone = String(body?.phone || '').replace(/[ -]/g, '');
  const password = String(body?.password || '');
  if ((!email && !phone) || password.length < 6) return response({ error: 'Invalid login details.' }, 400);

  const url = Deno.env.get('SUPABASE_URL') || '';
  const serviceRole = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  if (!url || !serviceRole) return response({ error: 'Server auth configuration is missing.' }, 500);

  const admin = createClient(url, serviceRole, { auth: { autoRefreshToken: false, persistSession: false } });
  const anon = createClient(url, anonKey, { auth: { autoRefreshToken: false, persistSession: false } });
  const identity: any = email ? { email, password } : { phone, password };

  // First verify the supplied password through the normal Auth endpoint.
  const first = await anon.auth.signInWithPassword(identity);
  if (!first.error && first.data.session) {
    return response({
      user: first.data.user,
      access_token: first.data.session.access_token,
      refresh_token: first.data.session.refresh_token,
      expires_in: first.data.session.expires_in,
      token_type: first.data.session.token_type
    });
  }

  const firstMsg = String(first.error?.message || '').toLowerCase();
  const confirmationError = firstMsg.includes('email not confirmed') || firstMsg.includes('email_not_confirmed') ||
    firstMsg.includes('phone not confirmed') || firstMsg.includes('phone_not_confirmed');
  if (!confirmationError) return response({ error: first.error?.message || 'Invalid login details.' }, 401);

  // Correct password was supplied, but this legacy account is still marked unconfirmed.
  // Confirm only the matching account, then retry the same password login.
  let target: any = null;
  if (email) {
    const listed = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    if (listed.error) return response({ error: 'Unable to check account status.' }, 500);
    target = listed.data.users.find((u: any) => String(u.email || '').toLowerCase() === email) || null;
  } else {
    const listed = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    if (listed.error) return response({ error: 'Unable to check account status.' }, 500);
    target = listed.data.users.find((u: any) => String(u.phone || '').replace(/[ -]/g, '') === phone) || null;
  }

  if (!target?.id) return response({ error: 'Account not found.' }, 404);

  const update: any = {};
  if (email && target.email === email) update.email_confirm = true;
  if (phone && target.phone === phone) update.phone_confirm = true;
  const updated = await admin.auth.admin.updateUserById(target.id, update);
  if (updated.error) return response({ error: 'Unable to activate this account.' }, 500);

  const second = await anon.auth.signInWithPassword(identity);
  if (second.error || !second.data.session) return response({ error: second.error?.message || 'Login failed after account activation.' }, 401);

  return response({
    user: second.data.user,
    access_token: second.data.session.access_token,
    refresh_token: second.data.session.refresh_token,
    expires_in: second.data.session.expires_in,
    token_type: second.data.session.token_type
  });
});
