import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' }
  });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return response({ error: 'Method not allowed' }, 405);

  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
  const suppliedKey = req.headers.get('apikey') || '';
  if (!anonKey || suppliedKey !== anonKey) return response({ error: 'Unauthorized' }, 401);

  let body: any;
  try { body = await req.json(); } catch { return response({ error: 'Invalid JSON' }, 400); }

  const name = String(body?.name || '').trim();
  const email = String(body?.email || '').trim().toLowerCase();
  const mobile = String(body?.mobile || '').replace(/[ -]/g, '');
  const password = String(body?.password || '');

  if (!name) return response({ error: 'Full Name is required.' }, 400);
  if (!email && !mobile) return response({ error: 'Email or Mobile Number is required.' }, 400);
  if (email && !/^\S+@\S+\.\S+$/.test(email)) return response({ error: 'Invalid Email address.' }, 400);
  if (mobile && !/^\+?[0-9]{8,18}$/.test(mobile)) return response({ error: 'Invalid Mobile Number.' }, 400);
  if (password.length < 6) return response({ error: 'Password must be at least 6 characters.' }, 400);

  const url = Deno.env.get('SUPABASE_URL') || '';
  const serviceRole = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  if (!url || !serviceRole) return response({ error: 'Server auth configuration is missing.' }, 500);

  const admin = createClient(url, serviceRole, { auth: { autoRefreshToken: false, persistSession: false } });
  const anon = createClient(url, anonKey, { auth: { autoRefreshToken: false, persistSession: false } });

  try {
    const created = await admin.auth.admin.createUser({
      email: email || undefined,
      phone: mobile || undefined,
      password,
      email_confirm: !!email,
      phone_confirm: !!mobile,
      user_metadata: { full_name: name, name, mobile: mobile || '' }
    });

    if (created.error) return response({ error: created.error.message }, created.error.status || 400);

    const identity = email ? { email, password } : { phone: mobile, password };
    const signedIn = await anon.auth.signInWithPassword(identity as any);
    if (signedIn.error || !signedIn.data.session) {
      return response({ error: signedIn.error?.message || 'Account created but automatic login failed.' }, 400);
    }

    return response({
      user: signedIn.data.user,
      access_token: signedIn.data.session.access_token,
      refresh_token: signedIn.data.session.refresh_token,
      expires_in: signedIn.data.session.expires_in,
      token_type: signedIn.data.session.token_type
    });
  } catch (e) {
    return response({ error: e instanceof Error ? e.message : 'Account creation failed.' }, 500);
  }
});
