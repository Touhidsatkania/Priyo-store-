# PRIYO STORE V96

- Version: 1.0.96 (baseline source versionCode 96)
- Application ID: com.priyostore.app
- Android target/compile SDK: 35

This build is based on the V95 authentication/dashboard project and keeps the approved Login → Create Account → Dashboard flow.

Key V96 fixes:
- Direct account creation/login without OTP or verification.
- Correct Remember Me persistence behavior.
- Backend-driven Admin recognition; no separate Admin Login board.
- CI-generated unique effective Android versionCode for each build.
- Versioned APK artifacts and build metadata.

Release signing note: a persistent Android release keystore is still required for install-over-update of an already-installed signed release APK.
