# PRIYO STORE V97 — Permanent Signing Setup

## Purpose
This package prepares PRIYO STORE for permanent release signing and future APK updates.

## New permanent key
- Keystore: PRIYO_STORE_RELEASE_2026.jks
- Alias: priyostore
- See `keystore/KEEP_PRIVATE.txt` for the certificate fingerprint and private credentials.

The private keystore is included only for private backup. Do NOT commit it to GitHub.

## GitHub Actions secrets
Create these repository secrets:
1. `PRIYO_STORE_KEYSTORE_B64` — base64 contents of `PRIYO_STORE_RELEASE_2026.jks`
2. `PRIYO_STORE_KEYSTORE_PASSWORD` — the keystore password from `KEEP_PRIVATE.txt`
3. `PRIYO_STORE_KEY_ALIAS` — `priyostore`
4. `PRIYO_STORE_KEY_PASSWORD` — the key password from `KEEP_PRIVATE.txt`

The workflow reconstructs the keystore only inside the runner and uses it only during the release build.

## Important update rule
Android requires an update to match the installed app's signing identity. A newly generated key cannot update an older APK signed by a different key. Therefore:
- If the old installed PRIYO STORE APK was signed with the old key, recover/use that old key instead.
- If the old key is permanently unavailable, install V97 as a new installation once (after removing the old app if Android refuses an update). From V97 onward, keep this new key forever for all releases.

## Versioning
V97 source version is 1.0.97. CI uses a run-based versionCode (`100000 + GitHub run number`) so a successful build is never reused with the same Android versionCode.

## Required final verification
1. Add the four GitHub Actions secrets.
2. Run the V97 workflow.
3. Confirm `Verify signed APK` passes.
4. Download the signed APK.
5. Check that it installs.
6. On a device where V97 is installed, build V98 with the same key and higher versionCode.
7. Confirm V98 installs over V97 without uninstalling.
8. Never lose the JKS or its passwords.
