PRIYO STORE V77 — NO EMAIL VERIFICATION STEP

Changes:
- Removed the V76 email OTP/verification-code UI from Create Account.
- Create Account now calls Supabase Auth /auth/v1/signup with email + password + name.
- When Supabase returns an access token, the user is logged in immediately and the normal PRIYO STORE session is created.
- Existing Login, Mobile login, role handling, admin visibility and other app features are preserved.
- The old V76 verification functions and controls are no longer wired into the login screen.

IMPORTANT SUPABASE SETTING:
- Supabase Dashboard > Authentication > Providers > Email: turn OFF “Confirm email” if the goal is to allow account creation/login without email verification.
- SMTP is not required for this no-verification signup flow.
