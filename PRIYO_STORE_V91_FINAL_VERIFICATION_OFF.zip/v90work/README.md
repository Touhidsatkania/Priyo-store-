PRIYO STORE V91 — FINAL AUTH FIX

Version: 1.0.91 (versionCode 91)

Authentication changes:
- Email Create Account no longer sends or asks for a verification code.
- Email Login no longer sends or asks for a verification code or trusted-device OTP.
- Create Account uses the Supabase password signup endpoint directly.
- When Supabase returns an access token, the real session is stored before Dashboard opens.
- Existing session validation on app startup is retained.
- Kotlin dependency resolution is pinned to 1.8.22 to avoid the duplicate kotlin-stdlib/jdk7/jdk8 classes seen in the failed V91 build.

Build: GitHub Actions workflow is configured for V91.
