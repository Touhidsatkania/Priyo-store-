PRIYO STORE V90 — LOGIN SESSION FIXED

Problems fixed:
- First-device email login: after OTP verification, the existing Supabase access token is now explicitly passed into enter(), so the real session is saved before Dashboard opens.
- Trusted-device email login: the fresh Supabase token is saved before Dashboard opens.
- App restart: stored session is checked against /auth/v1/user before Dashboard access.
- Version metadata corrected to Android versionCode 90 / versionName 1.0.90; the previous V89 package still reported versionCode 87.
- GitHub Actions workflow/artifact labels updated from V85 to V90.

Validation:
- All embedded JavaScript blocks pass Node --check.
- ZIP integrity verified after packaging.
- Android project structure retained.
