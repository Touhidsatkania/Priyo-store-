PRIYO STORE V76

Changes:
- Create Account now sends an email verification code through the PRIYO APP Supabase Auth project.
- Verification code must be entered before account creation completes.
- Email login uses Supabase Auth instead of storing email passwords locally.
- Admin role is detected automatically from the configured Admin email and opens Admin Control Center after successful login.
- Removed the Admin email explanatory note from the login screen.
- Mobile login remains supported for existing local mobile accounts.
