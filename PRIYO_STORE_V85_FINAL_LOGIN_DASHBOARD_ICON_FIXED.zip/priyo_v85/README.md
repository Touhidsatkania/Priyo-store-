# PRIYO STORE

- Version: 1.0.82 (versionCode 82)
- Application ID: com.priyostore.app
- Android target/compile SDK: 35

This build contains the startup/WebView reliability fix, launcher icon configuration, role-aware Admin access, and email verification flow.
