# PRIYO STORE V96

- Version: 1.0.96 (baseline source versionCode 96)
- Application ID: com.priyostore.app
- Android target/compile SDK: 35

This build is based on the V95 authentication/dashboard project and keeps the approved Login → Create Account → Dashboard flow.

Key V96 fixes:
- Direct account creation/login without OTP or verification.
- Correct Remember Me persistence behavior.
- Backend-driven Admin recognition; no separate Admin Login board.
- CI-generated unique effective Android versionCode for each build.
- Versioned APK artifacts and build metadata.

Release signing note: a persistent Android release keystore is still required for install-over-update of an already-installed signed release APK.


## V98 Login → Dashboard working candidate
- Version 1.0.98 candidate.
- Successful authenticated login/create-account session opens the main dashboard directly.
- Admin recognition first checks the authenticated Supabase email against the configured admin ID, then falls back to the backend admin-role RPC.
- No separate Admin Login board or visible Admin marker is introduced.
- This is a working candidate, not final success, until the signed APK is installed and the full Login → Session → Dashboard flow is physically tested.
