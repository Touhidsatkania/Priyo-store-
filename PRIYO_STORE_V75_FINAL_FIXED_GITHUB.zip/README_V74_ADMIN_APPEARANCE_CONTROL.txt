PRIYO STORE V74 — ADMIN APPEARANCE + FULL HOME CONTENT CONTROL

Implemented on top of V72 CLEAN FINAL FIXED.

1. Preserved V72 dashboard structure and approved asset references.
2. Added Admin Control Center → Home Content.
   - Welcome title/brand/subtitle/image
   - Notification badge count
   - Add/edit/enable/disable/reorder promo cards
3. Added Admin Control Center → Appearance.
   - Background gradient / solid color / image
   - Background image URL or device image
   - Background/card/text/muted/primary/accent colors
   - Reset to defaults
4. Added Admin Control Center → Branding.
   - Dashboard/WebView app name
   - Dashboard/WebView logo/icon URL or device image
5. Existing Feature/Banner/Breaking News/Live/Moderator controls remain.
6. Important limitation: the installed Android launcher icon is a packaged APK resource and cannot be changed dynamically by WebView localStorage. Changing the launcher icon requires a new APK build.
7. Added the supplied dashboard and icon reference images to assets for project documentation/reference.
8. Version advanced to 1.0.74 / versionCode 74.

Validation: index.html JavaScript syntax checked successfully with Node.js.
Local Android Gradle build was not run because Gradle is not installed in this environment; CI workflow remains configured to build cleanly on GitHub Actions.
