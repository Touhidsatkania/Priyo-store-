PRIYO STORE V72 — CLEAN FINAL FIXED

Package: com.priyostore.app
Version: 1.0.72 (72)
Brand: PRIYO STORE

This source contains only the active V72 project.
Old nested V71/V70/V69/etc. project copies have been removed.
Launcher icon is the approved PS icon.
Round launcher icon now correctly points to ic_launcher_round.

Build through GitHub Actions workflow:
.github/workflows/android-build.yml

The workflow cleans app/build before compiling and verifies package,
version, label, launcher icon and source structure before building.
