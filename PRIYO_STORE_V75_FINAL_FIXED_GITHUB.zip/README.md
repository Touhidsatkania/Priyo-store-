# PRIYO STORE

PRIYO STORE Android project — V75 Final Clean.

## GitHub upload
Extract this ZIP and upload the CONTENTS of this folder to the repository root.
Do not upload the ZIP itself and do not create an extra nested project folder.

The Android application is configured as:
- App name: PRIYO STORE
- Application ID: com.priyostore.app
- Version: 1.0.75 (versionCode 75)
- Launcher icon: PRIYO STORE final launcher icon
